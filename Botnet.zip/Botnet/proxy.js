const { exec } = require('child_process');

function runScrape() {
    exec('node SCRAPE.js', (error, stdout, stderr) => {
        if (error) {
            console.error(`Error: ${error.message}`);
            return;
        }
        if (stderr) {
            console.error(`Stderr: ${stderr}`);
            return;
        }
        console.log(`Output: ${stdout}`);
        console.log(`Scraping selesai pada ${new Date()}`);
    });
}

setInterval(runScrape, 1800000);
runScrape();